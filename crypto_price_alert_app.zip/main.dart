// A very simple Flutter app that checks BTC, ETH, and SOL prices every minute
// and sends a local notification if the price moves beyond a set threshold.

import 'package:flutter/material.dart';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Crypto Alert',
      home: PriceAlertPage(),
    );
  }
}

class PriceAlertPage extends StatefulWidget {
  @override
  _PriceAlertPageState createState() => _PriceAlertPageState();
}

class _PriceAlertPageState extends State<PriceAlertPage> {
  Map<String, double?> lastPrices = {"BTC": null, "ETH": null, "SOL": null};
  final thresholds = {"BTC": 1000, "ETH": 50, "SOL": 5};
  FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

  @override
  void initState() {
    super.initState();
    _initNotifications();
    Timer.periodic(Duration(minutes: 1), (_) => checkPrices());
  }

  Future<void> _initNotifications() async {
    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const initializationSettings = InitializationSettings(android: androidSettings);
    await flutterLocalNotificationsPlugin.initialize(initializationSettings);
  }

  Future<void> showNotification(String title, String body) async {
    const androidDetails = AndroidNotificationDetails(
      'crypto_channel',
      'Crypto Alerts',
      importance: Importance.high,
      priority: Priority.high,
    );
    const platformDetails = NotificationDetails(android: androidDetails);
    await flutterLocalNotificationsPlugin.show(0, title, body, platformDetails);
  }

  Future<void> checkPrices() async {
    final response = await http.get(Uri.parse('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,solana&vs_currencies=usd'));
    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      final prices = {
        "BTC": data['bitcoin']['usd'] * 1.0,
        "ETH": data['ethereum']['usd'] * 1.0,
        "SOL": data['solana']['usd'] * 1.0
      };

      prices.forEach((symbol, currentPrice) {
        final lastPrice = lastPrices[symbol];
        if (lastPrice != null) {
          final difference = (currentPrice - lastPrice).abs();
          if (difference >= thresholds[symbol]!) {
            showNotification('$symbol Alert', 'Price changed \$${difference.toStringAsFixed(2)} to \$${currentPrice.toStringAsFixed(2)}');
          }
        }
        lastPrices[symbol] = currentPrice;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Crypto Price Alerts')),
      body: Center(child: Text('Monitoring BTC, ETH, and SOL prices...')),
    );
  }
}
